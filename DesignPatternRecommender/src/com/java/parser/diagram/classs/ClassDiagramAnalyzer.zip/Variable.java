package com.java.parser.diagram.classs;

public class Variable {
	public String name;
	public String type;
	public String visibility;
}
