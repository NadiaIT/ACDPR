package com.java.parser.diagram.classs;

public class ClassRelation {
	public String sourceClassId;
	public String destinationClassId;
	public CLASS_RELATION_TYPE relationType;
}
