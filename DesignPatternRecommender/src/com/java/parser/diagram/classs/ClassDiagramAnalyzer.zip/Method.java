package com.java.parser.diagram.classs;

import java.util.ArrayList;

public class Method {
	public String name;
	public ArrayList<Variable> parameters;
	public String returnType;
	public String visibility;
}
