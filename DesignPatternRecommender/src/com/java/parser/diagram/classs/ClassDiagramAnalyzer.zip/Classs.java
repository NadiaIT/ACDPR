package com.java.parser.diagram.classs;

import java.util.ArrayList;

public class Classs {
	public String identifier;
	public String name;
	public ArrayList<Variable> variables;
	public ArrayList<Method> methods;
	public boolean isAbstract;
	public boolean isInterface;
}
